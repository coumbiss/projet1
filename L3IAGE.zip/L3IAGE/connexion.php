<?php 
    $host="localhost";
    $user="root";
    $mdp="";
    $bd="projetl3iage";
    $connexion=mysqli_connect($host, $user, $mdp, $bd);
    if(!$connexion) {
    echo "Erreur de Connexion a la Base de Donnes ";
}
?>