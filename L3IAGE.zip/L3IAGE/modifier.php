
<?php 
if(isset($_POST["modifier"])){
    $id=$_POST["id"];
    $Code=$_POST["Code"];
    $Nom=$_POST["Nom"];
    $Des=$_POST["Des"];
    $Bud=$_POST["Bud"];
    $Dd=$_POST["Dd"];
    $Df=$_POST["Df"];
    $st=$_POST["st"];
    $sql="UPDATE projet set Code='$Code', Nom='$Nom', Descriptio='$Nom' Budget='$Bud', DateD='$Dd', DateF='$Df', Statut='$st'
    where id=$id";
      mysqli_query($connexion,$sql);
      header("location:index.php");

 

}
?>

    <div class="col-md-8 offset-2 mt-5">

<form action="" method="POST">
<input type="text" name="id" value= "<?php echo $ligne[0] ?>" hidden>
    <label for="">Code</label>
    <input type="" name="Code"  value= "<?php echo $ligne[1] ?>" class="form-control">
    <br>
    <label for="">Nom</label>
    <input type="text" name="Nom"  value= "<?php echo $ligne[2] ?>" class="form-control">
    <br>
    <label for="">Description</label>
    <input type="text" name="Des"   value= "<?php echo $ligne[3] ?>" class="form-control">
    <br>
    <label for="">Budget</label>
    <input type="" name="Bud"   value= "<?php echo $ligne[4] ?>" class="form-control">
    <br>
    <label for="">DateD</label>
    <input type="date" name="Dd"   value= "<?php echo $ligne[5] ?>" class="form-control">
    <br>
    <label for="">DateF</label>
    <input type="date" name="Df" value= "<?php echo $ligne[6] ?>"  class="form-control">
    <br>
    <label for="">Statut</label>
    <input type="booleen" name="st" value= "<?php echo $ligne[7] ?>"  class="form-control">
 
    <br>
    <button type="submit" name="modifier" class="btn btn-success">Modifier</button>
    <button type="annuler" name="annuler" class="btn btn-dark">Retour</button>
   

</form>