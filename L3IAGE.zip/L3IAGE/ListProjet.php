<div class="col-md-8 offset-2 mt-5">
<a href="?page=ajouter" class="btn btn-dark">Ajouter</a>
  
    <?php

$sql="SELECT * FROM projet";
 $result=mysqli_query($connexion,$sql);
 var_dump($result);
 var_dump(mysqli_fetch_row($result));
 

 

?>
<table class="table">

  <thead>
    <tr>
      <th scope="col">id</th> 
      <th scope="col">Code</th>
      <th scope="col">Nom</th>
      <th scope="col">Description</th>
      <th scope="col">Budget</th>
      <th scope="col">DateD</th>
      <th scope="col">DateF</th>
      <th scope="col">Statut</th>
      <th>choix</th>
    </tr>
  </thead>
 
  </tbody>
  <?php while($ligne=mysqli_fetch_row($result)):?>
 <tr>
  <td> <?php echo $ligne[0] ;?> </td>
  <td> <?php echo $ligne[1] ;?> </td>
  <td> <?php echo $ligne[2] ;?> </td>
  <td> <?php echo $ligne[3] ;?> </td>
  <td> <?php echo $ligne[4] ;?> </td>
  <td> <?php echo $ligne[5] ;?> </td>
  <td> <?php echo $ligne[6] ;?> </td>
  <td> <?php echo $ligne[7] ;?> </td>
<td> 
   <a href="?page=modifier&id=<?php echo $ligne[0] ?>" class="btn btn-primary">Modifier</a>
  <a href="?page=delete&id=<?php echo $ligne[0] ?>"  class="btn btn-danger">Supprimer</a>

  </td>


</tr>

  <?php endwhile ?>
 
</table>
     