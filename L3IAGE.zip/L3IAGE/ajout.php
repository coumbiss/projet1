<?php 
if(isset($_POST["ajouter"])){
    $Code=$_POST["Code"];
    $Nom=$_POST["Nom"];
    $Des=$_POST["Des"];
    $Bud=$_POST["Bud"];
    $Dd=$_POST["Dd"];
    $Df=$_POST["Df"];
    $st=$_POST["st"];
    
    $sql="INSERT INTO projet values(NULL,'$Code','$Nom','$Des','$Bud','$Dd','$Df', $st)";
    mysqli_query($connexion,$sql);
    header("location:index.php");
 

}
?>



<div class="col-md-8 offset-2 mt-5">

<form action="" method="POST">
    <label for="">Code</label>
    <input type="text" name="Code" class="form-control">
    <br>
    <label for="">Nom</label>
    <input type="text" name="Nom" class="form-control">
    <br>
    <label for="">Description</label>
    <input type="text" name="Des" class="form-control">
    <br>
    <label for="">Budget</label>
    <input type="text" name="Bud" class="form-control">
    <br>
    <label for="">DateD</label>
    <input type="date" name="Dd" class="form-control">
    <br>
    <label for="">DateF</label>
    <input type="date" name="Df" class="form-control">
    <br>
    <label for="">Statut</label>
    <input type="booleen" name="st" class="form-control">
 
    <br>
    <button type="submit" name="ajouter" class="btn btn-success">Ajouter</button>
    <button type="annuler" name="annuler" class="btn btn-dark">Retour</button>
   

</form>