<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap.min.css">
    <title>L3IAGE</title>
</head>
<body>

<?php 

require_once ("connexion.php");
require_once ("nav.php");
if(isset($_GET['page'])){
    switch($_GET["page"]){
        case "delete":
            $id=$_GET['id'];
            $sql="DELETE FROM projet WHERE id=".$id;
            mysqli_query($connexion,$sql);
            header("location:index.php");
            break;
            case "ajouter":
            require_once("ajout.php");
            break;
            case "modifier":
                $id=$_GET['id'];
                $sql="SELECT * FROM projet where id=$id";
               $resul= mysqli_query($connexion,$sql);
               $ligne=mysqli_fetch_row($resul);
               var_dump($ligne);
               require_once("modifier.php");
               break;


     }

}else{
    require_once("ListProjet.php");
}
    

?>
</body>
</html>